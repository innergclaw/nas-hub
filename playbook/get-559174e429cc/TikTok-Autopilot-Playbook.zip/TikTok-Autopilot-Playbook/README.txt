THE LOCAL BUSINESS TIKTOK AUTOPILOT PLAYBOOK
by InnerG Intel

Thanks for grabbing the playbook.

WHAT'S IN THIS FOLDER
- The-Local-Business-TikTok-Autopilot-Playbook.pdf  -> the full step-by-step guide
- Prompt-Pack.txt        -> every copy-paste prompt in one place
- Caption-Templates.csv  -> caption + CTA templates (opens in Excel / Google Sheets)

START HERE
1. Open the PDF and follow Steps 1-3 (about 20 minutes).
2. Keep Prompt-Pack.txt open while you post.
3. Use the 30-minute weekly routine to stay consistent.

Plans and limits for Claude, Metricool and TikTok can change.
Check each tool's pricing page before relying on a limit.

For personal or single-business use. Please don't resell or redistribute.
